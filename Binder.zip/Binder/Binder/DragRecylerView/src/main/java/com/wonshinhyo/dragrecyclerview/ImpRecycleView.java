package com.wonshinhyo.dragrecyclerview;

import androidx.recyclerview.widget.RecyclerView;

/**
 * Created by Shinhyo on 2016. 6. 15..
 */

public interface ImpRecycleView {

    void setAdapter(RecyclerView.Adapter adapter);
}
