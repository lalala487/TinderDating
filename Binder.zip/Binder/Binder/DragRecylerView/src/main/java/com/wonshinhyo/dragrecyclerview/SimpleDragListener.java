package com.wonshinhyo.dragrecyclerview;

/**
 * Created by Shinhyo on 2016. 6. 13..
 */
public class SimpleDragListener implements OnDragListener {

    @Override
    public void onMove(int fromPosition, int toPosition) {
    }

    @Override
    public void onSwiped(int position) {
    }

    @Override
    public void onDrop(int fromPosition, int toPosition) {
    }


}
