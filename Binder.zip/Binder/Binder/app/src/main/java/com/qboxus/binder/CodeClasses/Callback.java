package com.qboxus.binder.CodeClasses;

/**
 * Created by AQEEL on 4/4/2019.
 */

public interface Callback {

    void Responce(String resp);
}
