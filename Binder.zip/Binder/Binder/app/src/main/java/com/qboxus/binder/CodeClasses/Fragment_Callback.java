package com.qboxus.binder.CodeClasses;

import android.os.Bundle;

/**
 * Created by AQEEL on 4/4/2019.
 */

public interface Fragment_Callback {

    void Responce(Bundle bundle);
}
