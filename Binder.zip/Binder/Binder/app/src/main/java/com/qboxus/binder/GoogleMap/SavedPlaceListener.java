package com.qboxus.binder.GoogleMap;

import java.util.ArrayList;

/**
 * Created by Nabeel on 3/13/2018.
 */

interface SavedPlaceListener {
    public void onSavedPlaceClick(ArrayList<SavedAddress> mResultList, int position);
}
